package regularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class main {

	public static void main(String[] args) {
		String strPattern = "hello";
		String strCheck = "Hello World";
		Pattern pattern = Pattern.compile(strPattern, Pattern.CASE_INSENSITIVE);
		Matcher matcherCheck = pattern.matcher(strCheck);
		
		if (matcherCheck.find())
		{
	      	System.out.println( "Pattern-string match found in Check-string" );
	    }
		else
		{
			System.out.println( "Pattern-string match not found in Check-string" );
		}

	}

}
