package collections;

import java.util.ArrayList;

public class arrayList {
	
	void arrayOfFruits()
	{
	
		System.out.println("\n\t Collection: ArrayList of diferent Fruits \n");
		ArrayList<String> fruits = new ArrayList<String>();   
		fruits.add("Apple");
		fruits.add("Mango");
		fruits.add("Cherry");
		fruits.add("Orange");
		fruits.add("Lychee");
		System.out.println(fruits);  

}
}
