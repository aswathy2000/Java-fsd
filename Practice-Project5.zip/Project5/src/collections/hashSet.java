package collections;

import java.util.HashSet;

public class hashSet {

	void hashSetEmpId()
	{
		System.out.println("\n\t Collection: HashSet \n");
		HashSet<Integer> empId = new HashSet<Integer>();  
		empId.add(101);  
		empId.add(102);  
		empId.add(103);
		System.out.println(empId);
		
	}
}
