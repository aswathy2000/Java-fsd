package collections;

public class collectionTypes {

	public static void main(String[] args) {
		
		//ArrayList 
		arrayList objarraylist = new arrayList();
		objarraylist.arrayOfFruits();
		
		
		System.out.println("\n******************************************************************");

		
		//Vector
		
		vector objvector = new vector();
		objvector.vectorOfNos();
		
		
		System.out.println("\n******************************************************************");
		

		//LinkedList
		
		linkedList objlinkedList = new linkedList();
		objlinkedList.linkedListEmp();
			
			
		System.out.println("\n******************************************************************");

			
		//HashSet

		hashSet objhashSet = new hashSet();
		objhashSet.hashSetEmpId();
		
		System.out.println("\n******************************************************************");


		//LinkedHashSet

		linkedHashSet objlinkedHashSet = new linkedHashSet();
		objlinkedHashSet.linkedHashSetSalary();
			

	}

	}

