package collections;

import java.util.LinkedHashSet;

public class linkedHashSet {
	
	void linkedHashSetSalary()
	{
		System.out.println("\n\t Collection: LinkedHashSet \n");
		LinkedHashSet<Integer> empSalary = new LinkedHashSet<Integer>();  
		empSalary.add(10000);  
		empSalary.add(20000);  
		empSalary.add(30000);	       
		System.out.println(empSalary);
	}

}
