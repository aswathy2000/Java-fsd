package collections;

import java.util.Iterator;
import java.util.LinkedList;

public class linkedList {
	
	void linkedListEmp()
	{
	
	System.out.println("\n\t Collection: LinkedList \n");
	LinkedList<String> empNames = new LinkedList<String>();  
	empNames.add("Kim");  
	empNames.add("Tan");
	empNames.add("Annie");
	
	

	Iterator<String> i = empNames.iterator();  
	while(i.hasNext()){  
		System.out.println(i.next()); }
	}

}
