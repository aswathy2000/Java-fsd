package collections;

import java.util.Vector;

public class vector {
	
	void vectorOfNos()
	{
	
		System.out.println("\n\t Collection: Vector \n");
		Vector <Integer> vList = new Vector <Integer>();
		vList.add(10); 
		vList.add(20); 
		vList.add(30); 
		System.out.println(vList); 

}

}
