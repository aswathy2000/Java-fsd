import { Component } from '@angular/core';
import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})

@Directive({
  selector: '[appChangeColor]' // Directive selector
})


export class ProductComponent {

  pageTitle: string = "Product List Page";
   imageWidth:number = 80;
   imageMargin:number = 10;

   showImage:boolean = false;

   toggleImage() : void {
       this.showImage = !this.showImage;
       // (!false = true) // (!true == false)
 console.log('Value of ShowImage inside function ::',                              this.showImage);   
   }

   constructor(elem: ElementRef, renderer: Renderer2) {
    renderer.setStyle(elem.nativeElement, 'color', 'olive');
  }



}
