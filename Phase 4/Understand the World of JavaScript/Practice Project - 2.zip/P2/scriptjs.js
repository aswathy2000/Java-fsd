var x = (5 * 8) + 2;
var y = 2 * 3;
	
var result = myFunction(8,6);
console.log(result);
	
function myFunction(num1, num2) {
		var a = num1 * num2;
		var b = num1 + num2;
		return(a + b);
	}
	
console.log( myFunction(2, 4));
	
function toCelcius(f){
			return (5/9) * (f-32);
	}
	
console.log("The temperature is "+ toCelcius(101));
	
