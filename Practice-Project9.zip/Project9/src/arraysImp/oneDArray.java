package arraysImp;

public class oneDArray {
	
	float arr[]= {1, 2, 3, 4, 5};

	void display() 
	{
		
		System.out.println("\n Elements of One Dimensional Array are: \n");
		for(int i=0 ; i<arr.length ; i++) 
		{
			System.out.print("\t " + arr[i]);
		}
	}
}