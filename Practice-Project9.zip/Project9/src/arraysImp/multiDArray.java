package arraysImp;

public class multiDArray {
	int[][] multiArr = {
			{5, 10, 15, 20, 25}, 
			{10, 20, 30, 40, 50} };

	void display() 
	{
		System.out.println("\n Elements of Multi Dimensional Array are: \n");
		for(int i=0 ; i<multiArr.length ; i++)
		{
			for(int j=0 ; j<multiArr[i].length ; j++) 
			{
				System.out.print("\t" + multiArr[i][j]);
			}
			System.out.print("\n");	
		}
	}

}
