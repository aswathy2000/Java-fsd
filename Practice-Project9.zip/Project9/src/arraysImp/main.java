package arraysImp;

public class main {

	public static void main(String[] args) {
		
		
		System.out.println("\n\t One Dimensional Array: \n");
		oneDArray objonedarr = new oneDArray();
		objonedarr.display();
		
		System.out.println("\n***************************************************");
		
		System.out.println("\n\t Multi Dimensional Array: \n");
		multiDArray objmultiarr = new multiDArray();
		objmultiarr.display();
	}

}
