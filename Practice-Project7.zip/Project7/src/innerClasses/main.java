package innerClasses;

public class main {

	public static void main(String[] args) {
		
		
		System.out.println("\n\t Nested Inner Class: \n");
		innerClass1.inner obj1 = new innerClass1(). new inner();
		obj1.display();
		
		
		System.out.println("\n***********************************************************************");
		
		
		System.out.println("\n\t Inner Class inside the method of an outer class: \n");
		methodInnerClass obj2 = new methodInnerClass();
		obj2.display();
		
		
		
		System.out.println("\n***********************************************************************");
		
		System.out.println("\n\t Anonymous Inner Class: \n");
		anonymousInnerClass obj3 = new anonymousInnerClass() {
			public void display()
			{
				System.out.println("\n Anonymous Inner Class \n");
			}
		};
		obj3.display();
		
		
		
		System.out.println("\n***********************************************************************");

	}

}
