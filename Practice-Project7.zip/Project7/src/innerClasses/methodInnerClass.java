package innerClasses;

public class methodInnerClass {
	
	void display()
	{
		System.out.println("Here, Outer class name: 'methodInnerClass' \n");
		
		class innerClass
		{
			
			void displayInner()
			{
				System.out.println("Here Inner class,'innerClass' inside display method of outer class \n ");
			}
			
		}
		
		innerClass obj = new innerClass();
		obj.displayInner();
	}

}
