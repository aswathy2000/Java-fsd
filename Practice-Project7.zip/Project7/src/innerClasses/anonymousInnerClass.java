package innerClasses;

abstract class anonymousInnerClass {
	
	public abstract void display();

}
