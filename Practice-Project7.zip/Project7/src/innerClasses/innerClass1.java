package innerClasses;

public class innerClass1 {
	
	class inner{
		
		void display()
		{
			System.out.println("Here, inner class nested in class innerClass1 \n");
		}
	}
}
