

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.DBConnection;
import com.ecommerce.DbConstantPool;


/**
 * Servlet implementation class ProductDetails
 */
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		try {
			PrintWriter pw = response.getWriter();
			pw.println("<html><body>");



			DBConnection conn = new DBConnection(DbConstantPool.DB_URL,DbConstantPool.USERNAME,DbConstantPool.PASSWORD);
			CallableStatement stmt = conn.getConnection().prepareCall("{call add_product(?, ?)}");
			stmt.setString(1, "new product");
			stmt.setBigDecimal(2, new BigDecimal(1900.50));
			stmt.executeUpdate();

			pw.println("Successfully added product to 'eproduct' table using stored procedure and servlet ...<br><br>");
			
			pw.println("Products in 'eproduct' table are :<br><br>");
			ResultSet rst = stmt.executeQuery("select * from eproduct");
			
			while (rst.next()) {
				pw.println(rst.getInt("ID") + " : " + rst.getString("name") + "<Br>");
			}

			stmt.close();

			pw.println("</body></html>");
			conn.closeConnection();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
