package ImplicitExplicitTypeCasting;

public class explicitTypeCasting {
	
		
		public static void main(String[] args) {
			
			//Explicit Type Casting
					System.out.println("\n\t Writing a program in Java to implement Explicit Type Casting: \n");
					
					double var1 = 968.2589647631;
					
					int var2 = (int)var1;
					
					float var3 = (float)var1;
					
					long var4 = (long) var2;
					
					System.out.println("\n Double Variable-1: "+ var1);
					System.out.println("\n Double to Interger Variable-2: "+ var2);
					System.out.println("\n Double to Float Variable-3: "+ var3);
					System.out.println("\n Double to Long Variable-4: "+ var4);
			
		}

}


