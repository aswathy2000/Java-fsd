package ImplicitExplicitTypeCasting;

public class implicitTypeCasting {
	
	public static void main(String[] args) {
		
		//Implicit Type Casting
		System.out.println("\n\t Writing a program in Java to implement Implicit Type Casting: \n");
		
		char var1 = 'A';
		int var2 = var1;
		float var3 = var2;
		double var4 = var3;
		long var5 = var2;
		
		System.out.println("\n Character Variable-1: "+ var1);
		System.out.println("\n Character to Interger Variable-2: "+ var2);
		System.out.println("\n Interger to Float Variable-3: "+ var3);
		System.out.println("\n Float to Double Variable-4: "+ var4);
		System.out.println("\n Interger to Long Variable-5: "+ var5);

	}

}
