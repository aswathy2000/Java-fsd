package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
private Connection connection;
	
	public DBConnection(String dbURL, String user, String pwd) throws ClassNotFoundException, SQLException{
        
    	Class.forName(DbConstantPool.DRIVER_CLASS);
        this.connection = DriverManager.getConnection(DbConstantPool.DB_URL,DbConstantPool.USERNAME,DbConstantPool.PASSWORD);
    }
    
    public Connection getConnection(){
            return this.connection;
    }
    
    public void closeConnection() throws SQLException {
            if (this.connection != null)
                    this.connection.close();
    }

}
