package exceptionHandling;

public class balanceCheck {

	public void balanceChecking(double amtWithdrawal ) throws LowBalanceException
	{
		double balance = 100000;
		if (balance - amtWithdrawal >= 10000)
		{
			
			System.out.println("Successful Transcation!");
			System.out.println("Balance = " + (balance - amtWithdrawal) );
		}
		else 
		{
			throw new LowBalanceException();
		}
	}
}
