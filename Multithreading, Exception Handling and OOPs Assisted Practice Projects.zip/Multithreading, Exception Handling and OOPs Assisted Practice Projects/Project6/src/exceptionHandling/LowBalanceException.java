package exceptionHandling;

public class LowBalanceException extends Exception{
	
	public String toString()
	{
		return "Your balance is low to meet the transaction";
	}


}
