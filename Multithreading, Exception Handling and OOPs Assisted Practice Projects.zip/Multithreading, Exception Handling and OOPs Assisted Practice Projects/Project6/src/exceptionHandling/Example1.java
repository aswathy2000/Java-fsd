package exceptionHandling;

public class Example1{

	public static void main(String[] args) throws LowBalanceException {
		
		balanceCheck obj = new balanceCheck();
		obj.balanceChecking(10000);
		}
}

