
public class MyThread extends Thread{
	
	public void run()
 	{
  		System.out.println("\n\t Concurrent thread is running!!! \n");
 	}


	public static void main(String[] args) {
		
		
		MyThread objThread = new  MyThread();
		objThread.start();
	
	}

}
