
public class MyRunnableThread implements Runnable{
	
    public static int count = 0;
    public MyRunnableThread(){
         
    }
    
    public void run() {
    	
        while(MyRunnableThread.count <= 20){
        	
            try{
                System.out.println("\n Thread: " + (++(MyRunnableThread.count)));
                Thread.sleep(1000);
            } catch (InterruptedException intExcep) {
                System.out.println("\n Exception in thread: "+ intExcep.getMessage());
            }
        }
    } 



	public static void main(String[] args) {
		
		
		System.out.println("\n Start Main-Thread!!!");
        MyRunnableThread objMThread = new MyRunnableThread();
        Thread objTh = new Thread(objMThread);
        objTh.start();
        while(MyRunnableThread.count <= 20){
            try{
                System.out.println("\n Main Thread: " + (++(MyRunnableThread.count)));
                Thread.sleep(1000);
            } catch (InterruptedException intExcep){
                System.out.println("\n Exception in main thread: "+ intExcep.getMessage());
            }
        }
        System.out.println("\n End Main Thread!!!");
    }


	

}
