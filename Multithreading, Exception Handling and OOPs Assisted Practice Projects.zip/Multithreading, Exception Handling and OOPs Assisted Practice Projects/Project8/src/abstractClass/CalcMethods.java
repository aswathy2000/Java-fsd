package abstractClass;

public class CalcMethods extends CalculatorClass {

	@Override
	public void calcSum(int number1, int number2) {
		
		System.out.println("\n\t Sum of numbers: " + (number1 + number2));
		
	}

	@Override
	public void calcDifference(int number1, int number2) {
		
		System.out.println("\n\t Difference of numbers: " + (number1 - number2));
		
	}

}
