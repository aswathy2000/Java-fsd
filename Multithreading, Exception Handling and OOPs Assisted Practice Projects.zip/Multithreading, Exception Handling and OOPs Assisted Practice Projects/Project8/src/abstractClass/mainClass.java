package abstractClass;

public class mainClass {

	public static void main(String[] args) {
		
		CalcMethods objCalc = new CalcMethods();
		objCalc.calcSum(10, 20);
		objCalc.calcDifference(50, 30);
		
	}
}
