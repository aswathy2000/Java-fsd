package abstractClass;

public abstract class CalculatorClass {
	
	public abstract void calcSum(int number1, int number2);
	public abstract void calcDifference(int number1, int number2);
	
	void display()
	{
		System.out.println("\n\t Abstract Class \n");
	}

}
