package oopsConceptsDemo;

class Shape 
{
	int noOfSides = 4;
	
	void display()
	{
		System.out.println("\n\t This is Shape Class ");
		System.out.println("\t Number of Sides: " + noOfSides);
	}
}

class Square extends Shape
{
	int side = 10;
	double area = side * side;
	
	
	void display()
	{
		super.display();
		System.out.println("\n\t This is Square Class ");
		System.out.println("\t Area of Square: " + area);
	}
	
}

class Cube extends Square
{
	double volume = area * side;
	void display()
	{
		super.display();
		System.out.println("\n\t This is Cube Class ");
		System.out.println("\t Volume of Cube: " + volume);
	}
}


public class inheritanceDemo {

	public static void main(String[] args) {
		
		Cube obj = new Cube();
		obj.display();
	}

}
