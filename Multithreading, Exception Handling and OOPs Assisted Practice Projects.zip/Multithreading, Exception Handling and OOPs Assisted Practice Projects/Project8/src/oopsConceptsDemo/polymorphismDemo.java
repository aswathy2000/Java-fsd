package oopsConceptsDemo;

class findAreaOfShapes
{
	void area(double side)
	{
		final double PI = 3.14;
		System.out.println("\n\t Area of Circle is calculated - ");
		System.out.println("\t Area = " + (PI * side * side));
	}
	
	void area(int side)
	{
		System.out.println("\n\t Area of Square is calculated - ");
		System.out.println("\t Area = " + (side * side));
	}
	
	void area(int sideA, int sideB)
	{
		System.out.println("\n\t Area of Reactangle is calculated - ");
		System.out.println("\t Area = " + (sideA * sideB));
	}
	
	void area(double sideA, double sideB)
	{
		System.out.println("\n\t Area of Triangle is calculated - ");
		System.out.println("\t Area = " + (0.5 * sideA * sideB));
	}
	
}

public class polymorphismDemo {

	public static void main(String[] args) {
		
		findAreaOfShapes objShape = new findAreaOfShapes();
		objShape.area(10.0);
		objShape.area(20);
		objShape.area(20,30);
		objShape.area(40.0,50.0);
	}
}
