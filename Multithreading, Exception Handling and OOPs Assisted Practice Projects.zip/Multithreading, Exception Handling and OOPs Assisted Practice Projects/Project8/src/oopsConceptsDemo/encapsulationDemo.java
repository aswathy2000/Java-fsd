package oopsConceptsDemo;

import java.util.Scanner;

class courseDetails
{
	private int courseID;
	private String courseName;
	
	void getCourseDetails()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\n\t Enter Course ID: ");
		courseID = sc.nextInt();
		System.out.println("\n\t Enter Course Name: ");
		courseName = sc.next();
	}
	
//	public void setCourseID(int courseID) {
//		this.courseID = courseID;
//	}
//	public void setCourseName(String courseName) {
//		this.courseName = courseName;
//	}
	
	
	public int getCourseID() {
		return courseID;
	}
	public String getCourseName() {
		return courseName;
	}
}

public class encapsulationDemo {

	public static void main(String[] args) {
		
		courseDetails objCourse1 = new courseDetails();
		objCourse1.getCourseDetails();
		//objCourse1.setCourseID(1);
		//objCourse1.setCourseName("Maths");
		System.out.println("\n\t Course ID: " + objCourse1.getCourseID());
		System.out.println("\n\t Course Name: " + objCourse1.getCourseName());
	}
}
