package oopsConceptsDemo;

class Employee
{
	private int empID;
	private String empName;
	private String deptName;
	public Employee(int empID, String empName, String deptName) {
		this.empID = empID;
		this.empName = empName;
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Employee: empID = " + empID + ", empName = " + empName + ", deptName = " + deptName;
	}		
}

public class classObjDemo {

	public static void main(String[] args) {

		Employee objEmp1 = new Employee(1, "Kim", "Marketing");
		Employee objEmp2 = new Employee(2, "Tan", "Sales");
		Employee objEmp3 = new Employee(3, "Annie", "HR");
		System.out.println(objEmp1);
		System.out.println(objEmp2);
		System.out.println(objEmp3);
	}

}
