package abstractactionUsingInteraces;

public class main {

	public static void main(String[] args) {
		
		
		CalcMethods objCalc = new CalcMethods();
		objCalc.calcMultiplication(5, 10);
		objCalc.calcDivision(100, 10);

	}

}
