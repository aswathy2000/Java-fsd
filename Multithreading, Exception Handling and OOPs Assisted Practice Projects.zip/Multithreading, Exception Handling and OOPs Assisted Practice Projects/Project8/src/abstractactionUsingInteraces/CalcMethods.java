package abstractactionUsingInteraces;

public class CalcMethods implements CalcMenu{

	@Override
	public void calcMultiplication(int number1, int number2) {
		
		System.out.println("\n\t Multiplying both numbers, we get: " + (number1 * number2));
		
	}

	@Override
	public void calcDivision(int number1, int number2) {
		
		System.out.println("\n\t Dividing both numbers, we get: " + (number1 / number2));
		
	}

}
