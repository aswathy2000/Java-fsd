package abstractactionUsingInteraces;

public interface CalcMenu {
	
	public abstract void calcMultiplication(int number1, int number2);
	public abstract void calcDivision(int number1, int number2);
	
}

