package FileHandling;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ReadFileIntoList {


	public static List<String> readFileInList(String strFile) 
	{ 

		List<String> fileContent = Collections.emptyList(); 
		try
		{ 
			fileContent = Files.readAllLines(Paths.get(strFile), StandardCharsets.UTF_8); 
		} 

		catch (IOException exe) 
		{ 
			exe.printStackTrace(); 
		} 
		
		return(fileContent); 
	} 


	public static void main(String[] args) 
	{ 
		List fileList = readFileInList("C://Users//My Pc//Desktop//fileHandling.txt"); 

		Iterator<String> objIter = fileList.iterator(); 
		
		while (objIter.hasNext()) 
			System.out.println(objIter.next()); 


	}

}
