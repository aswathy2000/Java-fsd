package FileHandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class CreateNewFile {

	public static void main(String[] args) throws IOException {

		fileCreate();
	}

	private static void fileCreate() throws IOException
	{


		File objFile = new File("C://Users//My Pc//Desktop//fileHandling.txt");

		if 
		(objFile.createNewFile()){
			System.out.println("\n\t File 'fileHandling.txt' is created!!! \n");
		}
		else
		{
			System.out.println("\n\t File 'fileHandling.txt' already exists at the destination!!! \n");
		}

		FileWriter objWriteFile = new FileWriter(objFile);
		objWriteFile.write("File Handling Demo ");
		objWriteFile.close();
	}

}
