package FileHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileModificationProgram {

	static void textfileModifyMethod(String txtfileDestPath, String beforeTextinFile, String afterTextModify)
	{
		File modifyFile = new File(txtfileDestPath);
		String beforeText = "";
		BufferedReader objR = null;
		FileWriter objW = null;
		try
		{
			objR = new BufferedReader(new FileReader(modifyFile));
			String textLines = objR.readLine();
			while (textLines != null) 
			{
				beforeText = beforeText + textLines + System.lineSeparator();
				textLines = objR.readLine();
			}
			String newContent = beforeText.replaceAll(beforeTextinFile, afterTextModify);
			objW = new FileWriter(modifyFile);
			objW.write(newContent);
		}
		catch (IOException exeIO)
		{
			exeIO.printStackTrace();
		}
		finally
		{
			try
			{
				objR.close();
				objW.close();
			} 
			catch (IOException exepIO) 
			{
				exepIO.printStackTrace();
			}
		}
	}


	public static void main(String[] args) {

		textfileModifyMethod("C://Users//My Pc//Desktop//fileHandling.txt", "File Handling Demo", "File Modified");
		System.out.println("\n\t File - fileHandling.txt has been modified!!! \n");



	}

}
