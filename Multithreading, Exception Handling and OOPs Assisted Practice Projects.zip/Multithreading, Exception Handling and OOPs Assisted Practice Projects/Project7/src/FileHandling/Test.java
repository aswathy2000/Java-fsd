package FileHandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

public class Test {

	public static void main(String[] args) {
		
        try
        { 
        	System.out.println("\n\t Delete file - 'fileHandling.txt' \n");
            Files.deleteIfExists(Paths.get("C://Users//My Pc//Desktop//fileHandling.txt")); 
        } 
        catch(NoSuchFileException fileEXE1) 
        { 
            System.out.println("\n\t File does not exist!!! \n"); 
            fileEXE1.printStackTrace();
        } 

        catch(IOException fileEXE2) 
        { 
            System.out.println("\n\t IOException occurred!!! \n"); 
            fileEXE2.printStackTrace();
        } 
        
        finally
        {  
        System.out.println("\n\t File - 'fileHandling.txt' deleted successfully!!! \n"); 
        }


	}

}
