package exceptionsDemo;

import java.util.Scanner;

public class ThrowDemo {

	public static void main(String[] args) throws ArithmeticException{
		

		int number1,number2,result;
		Scanner sc = new Scanner(System.in);
		System.out.println("\n\t Enter two numbers for performing Division opertion: \t");
		number1 =sc.nextInt();
		number2 = sc.nextInt();

		try
		{
			if(number2 == 0)
			{
				throw new ArithmeticException ("\n\t Inavlid divisor!!! \n\tCannot divide by 0!!!\n");
			}
			else
			{
			result = number1 / number2;
			System.out.print("\n\t The result after division is : " + result);
			}
		}
		catch(ArithmeticException Exe)
		{
			System.out.print("\n\t Error occured : " + Exe.getMessage());

		}

	}

}
