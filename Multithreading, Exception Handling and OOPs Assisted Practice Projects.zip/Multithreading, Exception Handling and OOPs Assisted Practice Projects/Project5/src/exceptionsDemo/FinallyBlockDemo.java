package exceptionsDemo;

import java.util.Scanner;

public class FinallyBlockDemo {

	public static void main(String[] args) {
		
		int number1,number2,result=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("\n\t Enter two numbers for performing Division opertion: \t");
		number1 =sc.nextInt();
		number2 = sc.nextInt();

		try
		{
			result = number1 / number2;
		}
		catch(ArithmeticException Exe)
		{
			System.out.print("\n\t Error occured : " + Exe.getMessage());
		}
		finally
		{
			System.out.print("\n\t The result after division is : " + result);
		}


	}

}
