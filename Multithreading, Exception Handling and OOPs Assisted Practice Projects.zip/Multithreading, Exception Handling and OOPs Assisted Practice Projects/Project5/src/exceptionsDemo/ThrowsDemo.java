package exceptionsDemo;

import java.util.Scanner;

public class ThrowsDemo {

	public static void main(String[] args) {
		
   
		int number1,number2,result;
		Scanner sc = new Scanner(System.in);
		System.out.println("\n\t Enter two numbers for performing Division opertion: \t");
		number1 =sc.nextInt();
		number2 = sc.nextInt();

		try
		{
			result = number1 / number2;
			System.out.print("\n\t The result after division is : " + result);

		}
		catch(ArithmeticException Exe)
		{
			System.out.print("\n\t Error occured : " + Exe.getMessage());

		}

	}

}
