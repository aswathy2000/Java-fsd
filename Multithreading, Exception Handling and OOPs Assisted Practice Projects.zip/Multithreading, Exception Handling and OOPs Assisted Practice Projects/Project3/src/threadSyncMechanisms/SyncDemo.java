package threadSyncMechanisms;

class messageSendClass
{ 
    public void sendMessage(String message) 
    { 
        System.out.println("\n\t Sending message: '"  + message + "' \n"); 
        try
        { 
            Thread.sleep(2000); 
        } 
        catch (Exception e) 
        { 
            System.out.println("\n\t Thread  has been interrupted!!! \n"); 
        } 
        System.out.println("\n\t Sent Message : '" +  message + "' !!!\n"); 
    } 
} 
class threadClass extends Thread 
{ 
    private String messageStr; 
    private Thread threadEle; 
    messageSendClass  objMessageSend; 
    
    threadClass(String message,  messageSendClass objMS) 
    { 
    	messageStr = message; 
    	objMessageSend = objMS; 
    } 
  
    public void run() 
    {  
        synchronized(objMessageSend) 
        { 
        	objMessageSend.sendMessage(messageStr); 
        } 
    } 
} 


public class SyncDemo {

	public static void main(String[] args) {
		messageSendClass objMesSend = new messageSendClass(); 
		threadClass objThMessage1 = new threadClass( " First Message " , objMesSend ); 
		threadClass objThMessage2 = new threadClass( " Second Message " , objMesSend ); 
		objThMessage1.start(); 
		objThMessage2.start(); 
        try
        { 
        	objThMessage1.join(); 
        	objThMessage2.join(); 
        } 
        catch(Exception e) 
        { 
            System.out.println("\n\t Interruption Occurred !!!"); 
        } 


	}

}
