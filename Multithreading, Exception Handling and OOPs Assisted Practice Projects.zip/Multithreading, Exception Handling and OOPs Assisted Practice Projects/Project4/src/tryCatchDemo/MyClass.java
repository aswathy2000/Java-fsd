package tryCatchDemo;

import java.util.Scanner;

public class MyClass {

	public static void main(String[] args) {
		
		
		try {
			double[] doubleVlaues = {101.125, 101.456, 848.964, 246.798, 2000.010};
			System.out.println(doubleVlaues[6]);
		} 
		catch (Exception exe) 
		{
			System.out.println("\n\t Exception has occurred!!! \n");
			exe.printStackTrace();  
            System.out.println(exe); 
		} 
		finally 
		{
			System.out.println("\n\t The 'try-catch' block is executed!!! \n");
		}


	}
}


