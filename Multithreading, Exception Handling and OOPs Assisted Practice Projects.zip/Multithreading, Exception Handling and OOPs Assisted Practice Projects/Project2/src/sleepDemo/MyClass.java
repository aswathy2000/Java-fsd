package sleepDemo;

public class MyClass {
	
	
    private static Object objLOCK = new Object();

	public static void main(String[] args) throws InterruptedException {
		Thread.sleep(1500);
        System.out.println("\n\t Thread - '" + Thread.currentThread().getName() + "' - is woken after sleeping for 1.5 second!!!");
        synchronized (objLOCK) 
        {
        	objLOCK.wait(2000);
            System.out.println("\t Object - '" + objLOCK + "' - is woken after waiting for 2 seconds!!!");
        }


	}

}
