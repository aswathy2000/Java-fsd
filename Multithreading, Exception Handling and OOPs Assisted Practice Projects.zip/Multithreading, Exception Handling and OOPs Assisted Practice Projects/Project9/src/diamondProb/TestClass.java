package diamondProb;

interface interfaceOne
{  
    default void display() 
    { 
        System.out.println("\n\t Interface - 'interfaceOne' display() function \n"); 
    } 
} 
interface  interfaceTwo
{  
    default void display() 
    { 
        System.out.println("\n\t Interface - 'interfaceTwo' display() function \n"); 
    } 
}  


public class TestClass implements interfaceOne,interfaceTwo{
	
	 public void display() 
	    {  
	    	interfaceOne.super.display(); 
	    	interfaceTwo.super.display(); 
	    } 


	public static void main(String[] args) {
		
		TestClass objTestClass = new TestClass();
		objTestClass.display();
	   

	}

}
