package com.test.example;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;

public interface ProductRepository extends JpaRepository<ProductEntity, Integer>{

	

}
