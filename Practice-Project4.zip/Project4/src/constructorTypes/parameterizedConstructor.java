package constructorTypes;

public class parameterizedConstructor {

	parameterizedConstructor(double length, double breadth, double height)
	{
		System.out.println("Volume : " + length*breadth*height);
	}

}
