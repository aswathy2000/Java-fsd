package constructorTypes;

public class boxMain {

	public static void main(String[] args) {
		
		
		System.out.println("\n\t Default Constructor:\n ");
		defaultConstructor objdefault = new defaultConstructor();
		
		System.out.println("\n************************************* ");
		
		System.out.println("\n\t Parameterized Constructor:\n ");
		parameterizedConstructor objparameter = new parameterizedConstructor(30,30,30);

	}

}
