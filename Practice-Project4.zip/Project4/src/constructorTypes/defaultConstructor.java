package constructorTypes;

public class defaultConstructor {

	defaultConstructor() {

		double length = 10;
		double breadth = 10;
		double height = 10;


		System.out.println("Volume : " + length * breadth * height);


	}

}
