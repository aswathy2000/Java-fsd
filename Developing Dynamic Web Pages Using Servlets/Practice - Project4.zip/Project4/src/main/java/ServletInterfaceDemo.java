

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


/**
 * Servlet implementation class ServletInterfaceDemo
 */
public class ServletInterfaceDemo implements Servlet {
	
	
	ServletConfig configure = null;
	

	public void destroy() {		
		
		System.out.println("Destroy method...");		
	}

	public ServletConfig getServletConfig() {
		
		return null;
	}

	public String getServletInfo() {
		
		return "Successfull...";
	}

	public void init(ServletConfig configure) throws ServletException {
		
        this.configure = configure;
        System.out.println("Configuration completed...");

	}

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter pw = response.getWriter();
		pw.print("Servlet that implements the servlet interface...\n");
		pw.print("\nService method...");
			
	}

}
