package publicAccessSpecifiers;

public class mainClass {

	public static void main(String[] args) {
		
		publicAccessSpecifierClass objpublic = new publicAccessSpecifierClass();
		objpublic.display();

	}

}
