package publicAccessSpecifiers;

public class publicAccessSpecifierClass {

	public void display() {

		System.out.println("Public Access Specifier");
	}

}
