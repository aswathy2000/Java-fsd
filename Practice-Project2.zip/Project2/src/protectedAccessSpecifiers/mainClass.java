package protectedAccessSpecifiers;

public class mainClass {

	public static void main(String[] args) {
		
		protectedAccessSpecifierClass objprotected = new protectedAccessSpecifierClass();
		objprotected.display();

	}

}
