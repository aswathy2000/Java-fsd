package protectedAccessSpecifiers;

public class protectedAccessSpecifierClass {

	protected void display() {

		System.out.println("Protected Access Specifier");
	}

}
