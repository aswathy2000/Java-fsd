package defaultAccessSpecifiers;

public class mainClass {

	public static void main(String[] args) {
		
		defaultAccessSpecifierClass objdef = new defaultAccessSpecifierClass();
		objdef.display();

	}

}
