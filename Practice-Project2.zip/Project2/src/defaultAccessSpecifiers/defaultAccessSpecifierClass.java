package defaultAccessSpecifiers;

class defaultAccessSpecifierClass {

	void display() {
		
		System.out.println("Default Access Specifier");
	}

}
