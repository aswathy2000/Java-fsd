package privateAccessSpecifiers;

public class privateAccessSpecifierClass {
	
	
	private String output ;

	public privateAccessSpecifierClass(String output) {
		
		this.output = output;
	}

	public String getOutput() {
		return output;
	}
	
	
	

}
