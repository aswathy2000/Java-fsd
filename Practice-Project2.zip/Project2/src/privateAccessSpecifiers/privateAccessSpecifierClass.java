package privateAccessSpecifiers;

public class privateAccessSpecifierClass {

	private void display() {
		
		System.out.println("Private Access Specifier");
	}

}
