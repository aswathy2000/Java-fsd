package privateAccessSpecifiers;

public class mainClass {

	public static void main(String[] args) {
		
		privateAccessSpecifierClass objprivate = new privateAccessSpecifierClass("Private Access Specifier");
		System.out.println(objprivate.getOutput());

	}

}
