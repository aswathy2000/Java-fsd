package com.example;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;



public class App1 {

	public static void main(String[] args) throws InterruptedException {
		
		
		//register the webdriver =>browser vendor 
				WebDriverManager.chromedriver().setup();
				//creating an object to the object
				WebDriver wd=new ChromeDriver();
				//maximize the browser
				wd.manage().window().maximize();

				//webpage timebound 

				// wd.manage().timeouts().pageLoadTimeout(1,TimeUnit.MILLISECONDS);

				//go to browser and open this url 
				wd.get("file:///D:/ASWATHY/Mphasis/DOMAIN%20TRAINING/Phase%204/Codes/Class/15122023/alert.html");
				Alert alert=wd.switchTo().alert();
				System.out.println(alert.getText());
				alert.accept();
				Thread.sleep(2000);

				wd.close();

	}

}
