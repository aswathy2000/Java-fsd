package com.example;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App02 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver wd = new ChromeDriver();
		
		wd.manage().window().maximize();
		
		wd.get("https://www.amazon.in/");
		
		wd.findElement(By.cssSelector("input#twotabsearchtextbox")).sendKeys("iPhone");
		wd.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[2]/div/form/div[3]/div")).click();
		
		Thread.sleep(5000);
		
		wd.close();
		

	}

}
