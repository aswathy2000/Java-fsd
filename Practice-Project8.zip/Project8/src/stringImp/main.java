package stringImp;

public class main {

	public static void main(String[] args) {
		
		System.out.println("\n\t String Methods: \n");
		stringMethods objstrmethods = new stringMethods();
		objstrmethods.stringMeth();
		
		
		System.out.println("\n**********************************************************************\n");
		
		System.out.println("\n\t String buffer and String Builder: \n");
		stringBufferBuilder objstrbb = new stringBufferBuilder();
		objstrbb.stringBB();
		
	}

	}

