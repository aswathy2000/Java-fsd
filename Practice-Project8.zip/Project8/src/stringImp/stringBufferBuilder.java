package stringImp;

public class stringBufferBuilder {
	
	void stringBB()
	{

	System.out.println("\n\t Using StringBuffer and StringBuilder: \n");
	
	
	
	System.out.println("\n\t Using StringBuffer: \n");
	StringBuffer str = new StringBuffer();
	str.append("Lorem ipsum dolor sit amet, ");
	str.append("consectetuer adipiscing elit.");
	System.out.println(str);

	System.out.println(str.insert(0, 'A'));

	System.out.println(str.replace(0, 5, "abcde"));

	System.out.println(str.delete(0, 5));
	
	System.out.println(str.reverse());
	
	System.out.println(str.capacity());
	
	

	System.out.println("\n\t Using StringBuilder: \n");
	StringBuilder str1 = new StringBuilder("Hello,");
	str1.append(" I'm Kim Tan");
	System.out.println(str1);

	System.out.println(str1.delete(4, 5));

	System.out.println(str1.insert(8, "Hi "));

	System.out.println(str1.reverse());
	
	System.out.println(str1.capacity());

	
	System.out.println("\n");


	System.out.println("\n\t Conversion of Strings to StringBuffer and StringBuilder: \n");

	String string = "Lorem ipsum dolor sit amet"; 

	StringBuffer string1 = new StringBuffer(string); 
	System.out.println("\n\t Converting String to StringBuffer: \t" + string1);

	StringBuilder string2 = new StringBuilder(string); 
	System.out.println("\n\t Converting String to StringBuilder: \t" + string2);      		
}

}
