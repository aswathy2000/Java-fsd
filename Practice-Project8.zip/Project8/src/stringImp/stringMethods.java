package stringImp;

public class stringMethods {
	
	void stringMeth() {
	
		System.out.println("\n\t Different String Methods: \n");
		

		String str = new String("Hello, I'm Kim Tan");
		System.out.println(str.length());

		
		String strSub = new String(" Lorem ipsum dolor sit amet, consectetuer adipiscing elit. ");
		System.out.println(strSub.substring(10));
		
				
		System.out.println(strSub.trim());

		
		String str1="Lorem ipsum dolor sit amet";
		String str2="Lorem ipsum dolor sit amet";
		System.out.println(str1.compareTo(str2));

		
		String str3= "";
		System.out.println(str3.isEmpty());

		
		System.out.println(str.toLowerCase());
		
		System.out.println(str.toUpperCase());
		
		
		System.out.println(str.replace('l', 'L'));

		
		System.out.println(str1.equals(str2));

		
}
}
