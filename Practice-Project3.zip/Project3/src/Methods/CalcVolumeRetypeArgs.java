package Methods;

public class CalcVolumeRetypeArgs {


	double calVol1(double l, double b,double h) {
	
	return (l*b*h);

}
}
