package Methods;

public class CalcVolumeORetypeArgs {

	void calVol3(double l, double b,double h) {

		System.out.println(l*b*h);

	}

}
