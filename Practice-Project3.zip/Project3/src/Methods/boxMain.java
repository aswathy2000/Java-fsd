package Methods;


public class boxMain {

	public static void main(String[] args) {
		
		System.out.println("\n\tMethod with Return Type and Arguments: \n");
		CalcVolumeRetypeArgs obj1 = new CalcVolumeRetypeArgs();
		double volume1 = obj1.calVol1(10,10,10);
		System.out.println("Volume calculated using With Return Type, Args: "+ volume1);
		
		System.out.println("\n*********************************************************\n");

		
		System.out.println("\n\tMethod with Return Type and without Arguments: \n");
		CalcVolumeRetypeOArgs obj2 = new CalcVolumeRetypeOArgs();
		obj2.l1=20;
		obj2.b1=20;
		obj2.h1=20;
		double volume2 = obj2.calVol2();
		System.out.println("Volume calculated using With Return Type, No Args: "+ volume2);
		
		System.out.println("\n*********************************************************\n");
		
		
		System.out.println("\n\tMethod without Return Type and Arguments: \n");
		CalcVolumeORetypeArgs obj3 = new CalcVolumeORetypeArgs();
		System.out.println("Volume calculated using Without Return Type, with Args: ");
		obj3.calVol3(30,30,30);
		
		
		System.out.println("\n*********************************************************\n");
		
		
		
		System.out.println("\n\tMethod without Return Type and without Arguments: \n");
		CalcVolumeORetypeOArgs  obj4 = new CalcVolumeORetypeOArgs ();
		obj4.l=40;
		obj4.b=40;
		obj4.h=40;
		System.out.println("Volume calculated using without Return Type, No Args: ");
		obj4.calVol4();
		
	}

}
