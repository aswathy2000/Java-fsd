package Methods;

public class overloadFunctions {
	
	double area(double side) {
		System.out.println("\nArea of Square: ");
		return (side*side);
	}
	
	
	double area(double length, double breadth) {
		System.out.println("\nArea of Rectangle: ");
		return (length * breadth);
	}
	
	

	public static void main(String[] args) {
		overloadFunctions obj = new overloadFunctions();
		System.out.println(obj.area(10));
		System.out.println(obj.area(10,20));

	}

}
