package Methods;

public class CalcVolumeRetypeOArgs {

	double l1,b1,h1;

	double calVol2() {
		
		return (l1*b1*h1);

	}
}
