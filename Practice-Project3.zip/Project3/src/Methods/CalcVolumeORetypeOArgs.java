package Methods;

public class CalcVolumeORetypeOArgs {

	double l,b,h;

	void calVol4() {

		System.out.println(l*b*h);

	}

}
