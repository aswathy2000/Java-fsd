package Methods;

public class callByValue {
	
	
	int val=10;
	
	int scaleBy(int val)
	{
		return(val = val * 10);
	}

	public static void main(String[] args) {
		
		
		callByValue obj = new callByValue();
		System.out.println("Before Scaling: "+ obj.val);
		obj.scaleBy(100);
		System.out.println("After Scaling: "+ obj.val);
	}

}



