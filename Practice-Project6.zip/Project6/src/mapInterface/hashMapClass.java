package mapInterface;

import java.util.HashMap;
import java.util.Map;

public class hashMapClass {

	void hashMapFunc() {

		HashMap<Integer,String> empDetails = new HashMap<Integer,String>();      
		empDetails.put(101,"Kim");    
		empDetails.put(102,"Tan");    
		empDetails.put(103,"Annie");   

		System.out.println("\n\t Employee details are: \n");  
		for(Map.Entry<Integer,String> e:empDetails.entrySet()){    
			System.out.println("EmpId: " + e.getKey()+ ", EmpName: " + e.getValue());    
		}

	}

}
