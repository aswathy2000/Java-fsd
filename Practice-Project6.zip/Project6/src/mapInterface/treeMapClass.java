package mapInterface;

import java.util.Map;
import java.util.TreeMap;

public class treeMapClass<Char> {

	void treeMapFunc() {

		TreeMap<Integer,String> studentInfo = new TreeMap<Integer,String>();    
		studentInfo.put(001,"Aviso");    
		studentInfo.put(002,"Kim");    
		studentInfo.put(003,"Tan");       

		System.out.println("\n\t Student Information: \n");  
		for(Map.Entry<Integer,String> s:studentInfo.entrySet()){    
			System.out.println("StudentId: " + s.getKey() + ", StudentName: " + s.getValue());    
		}    

	}

}
