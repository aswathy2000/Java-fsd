package mapInterface;

import java.util.Hashtable;
import java.util.Map;

public class hashTableClass {

	void hashTableFunc() {

		Hashtable<Integer,String> np = new Hashtable<Integer,String>();  

		np.put(1,"The New York Times");  
		np.put(2,"The Wall Street Journal");  
		np.put(3,"The Washington Post");  
		 

		System.out.println("\n\t Popular Newspapers in the World: \n");  
		for(Map.Entry<Integer,String> n:np.entrySet()){    
			System.out.println("Rank: " + n.getKey() + ", Title: " + n.getValue());    
		}

	}


}
