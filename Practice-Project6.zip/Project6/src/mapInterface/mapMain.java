package mapInterface;


public class mapMain {

	public static void main(String[] args) {
		
		
		
		//HashMap
		System.out.println("\n\t HashMap Example: \n");
		hashMapClass objhashMap = new hashMapClass();
		objhashMap.hashMapFunc();
		
		System.out.println("\n***********************************************************");
		
		

		//TreeMap
		System.out.println("\n\t TreeMap Example: \n");
		treeMapClass objtreeMap = new treeMapClass();
		objtreeMap.treeMapFunc();
		
		System.out.println("\n***********************************************************");
		
		
		//HashTable
		System.out.println("\n\t HashTable Example: \n");
		hashTableClass objhashTable = new hashTableClass();
		objhashTable.hashTableFunc();

		

	}  

}


