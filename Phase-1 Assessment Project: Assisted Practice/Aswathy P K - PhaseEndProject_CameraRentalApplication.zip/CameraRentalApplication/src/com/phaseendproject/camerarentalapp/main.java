package com.phaseendproject.camerarentalapp;

public class main {

	public static void main(String[] args) 
	{
		loginPage.loginDisplay();
	}
}
